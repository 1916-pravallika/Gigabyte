package com.agriguard.backend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "diagnoses")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Diagnosis {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long cropId;
    private Long diagnosisId; // Frontend explicit diagnosis identifier
    private String crop;
    private String disease;
    private Double confidence;
    private String severity; // LOW, MODERATE, HIGH, CRITICAL

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
