package com.agriguard.backend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sales")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Sale {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long farmerId;
    private Long cropId;
    private Long buyerId;
    private String farmerName;
    private String cropName;
    private String buyerName;
    private Double quantity;
    private Double pricePerKg;
    private Double revenue;
    private Double storageCost;
    private Double transportCost;
    private Double otherCost;
    private Double expectedNetReturn;
    private String saleStatus; // e.g. CREATED, CONFIRMED, COMPLETED

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
