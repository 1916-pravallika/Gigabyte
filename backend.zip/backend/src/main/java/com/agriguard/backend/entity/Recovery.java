package com.agriguard.backend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "recoveries")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Recovery {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long diagnosisId;
    private Integer estimatedRecoveryDays;
    private String saleReadyStart;
    private String saleReadyEnd;
    private String cropCondition;
    private String recoveryStatus;
    private String estimatedSellingWindow;

    @Column(length = 500)
    private String disclaimer;

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
