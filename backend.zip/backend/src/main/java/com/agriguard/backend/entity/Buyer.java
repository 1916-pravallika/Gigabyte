package com.agriguard.backend.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "buyers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Buyer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String organizationName;
    private String cropName;
    private Double requiredQuantity;
    private Double offerPrice;
    private Boolean pickupAvailable;
    private Double distance;
    private String location;
    private String contact;
}
