package com.agriguard.backend.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "fpos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FPO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String cropName;
    private Double requiredQuantity;
    private Double expectedPrice;
    private Integer memberCount;
    private String location;
    private String contact;
}
