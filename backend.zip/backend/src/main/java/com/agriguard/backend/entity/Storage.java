package com.agriguard.backend.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "storages")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Storage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String location;
    private Double latitude;
    private Double longitude;
    private String capacity;
    private Double costPerDay;
    private String suitableCrops;
    private Double distance;
    private Boolean recommended;
}
