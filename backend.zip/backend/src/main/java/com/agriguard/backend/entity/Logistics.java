package com.agriguard.backend.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "logistics")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Logistics {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String transportType;
    private String capacity;
    private Double distance;
    private Double baseRate;
    private Double perKmRate;
    private Double estimatedCost;
    private Boolean availability;
}
